export class Food {
    _id: string;
    name:string;
    dates:string;
    exp_date:string;
}
